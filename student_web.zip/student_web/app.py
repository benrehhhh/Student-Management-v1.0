import sys
sys.path.insert(0,"db/")

from flask import Flask,render_template,redirect,request,url_for,flash
from werkzeug.utils import secure_filename
import os

from db.dbhelper import *

app = Flask(__name__)
app.secret_key = 'supersecretkey123'

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png','jpg','jpeg','gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
    
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def index()->None:
    students:list = getall('students')
    return render_template('index.html',studentlist=students)

@app.route("/add", methods=['POST'])
def add_student():
    idno = request.form['idno'].strip()
    lastname = request.form['lastname'].strip()
    firstname = request.form['firstname'].strip()
    course = request.form['course'].strip()
    level = request.form['level'].strip()

    # 🔹 Check for missing fields
    if not idno or not lastname or not firstname or not course or not level:
        flash("⚠️ All fields are required. Please fill in all fields before saving.", "error")
        return redirect(url_for('index'))

    # 🔹 Ensure ID number is numeric
    if not idno.isdigit():
        flash("⚠️ ID Number must be numeric.", "error")
        return redirect(url_for('index'))

    # 🔹 Check for existing ID number
    existing_student = getrecord('students', idno=idno)
    if existing_student:
        flash(f"⚠️ ID Number {idno} already exists!", "error")
        return redirect(url_for('index'))

    # 🔹 Handle image upload
    image_file = request.files.get('image')
    image_filename = None
    if image_file and allowed_file(image_file.filename):
        image_filename = f"{idno}_{secure_filename(image_file.filename)}"
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
        image_file.save(image_path)

    # 🔹 Save record if everything is valid
    addrecord('students', idno=idno, lastname=lastname, firstname=firstname,
               course=course, level=level, image=image_filename)
    flash("✅ Student record added successfully!", "success")
    return redirect(url_for('index'))


@app.route("/delete/<idno>")
def delete_student(idno):
    deleterecord('students', idno=idno)
    flash("✅ Student record deleted successfully!", "success")
    return redirect(url_for('index'))

@app.route("/edit/<idno>", methods=['GET', 'POST'])
def edit_student(idno):
    if request.method == 'POST':
        lastname = request.form['lastname'].strip()
        firstname = request.form['firstname'].strip()
        course = request.form['course'].strip()
        level = request.form['level'].strip()

        # 🔹 Block saving with missing fields
        if not lastname or not firstname or not course or not level:
            flash("⚠️ All fields must be filled before saving changes.", "error")
            return redirect(url_for('edit_student', idno=idno))

        image_file = request.files.get('image')
        record = getrecord('students', idno=idno)[0]

        if image_file and allowed_file(image_file.filename):
            if record['image']:
                old_path = os.path.join(app.config['UPLOAD_FOLDER'], record['image'])
                if os.path.exists(old_path):
                    os.remove(old_path)
            image_filename = f"{idno}_{secure_filename(image_file.filename)}"
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
            image_file.save(image_path)
        else:
            image_filename = record['image']

        updaterecord('students', idno=idno, lastname=lastname, firstname=firstname,
                     course=course, level=level, image=image_filename)
        flash("✅ Student record updated successfully!", "success")
        return redirect(url_for('index'))
    else:
        student = getrecord('students', idno=idno)[0]
        students = getall('students')
        return render_template('index.html', student=student, studentlist=students)

    
if __name__=="__main__":
    app.run(debug=True)