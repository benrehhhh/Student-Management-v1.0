import sys
import base64
sys.path.insert(0,"db/")

from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename
import sqlite3
import os

from db.dbhelper import *

students = []

app = Flask(__name__)
app.secret_key = 'supersecretkey123'

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png','jpg','jpeg','gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
    
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

DB_PATH = "db/users.db"
DB_ATTENDANCE_PATH = "db/school.db"

conn = sqlite3.connect(DB_ATTENDANCE_PATH)
c = conn.cursor()

# Fetch all attendance records
c.execute("SELECT id, time_in FROM attendance")
records = c.fetchall()

for rec_id, time_in in records:
    if time_in is None:
        continue
    try:
        # Case 1: already in 24-hour format -> skip
        datetime.strptime(time_in, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        try:
            # Case 2: stored as 'HH:MM AM/PM' -> convert
            dt = datetime.strptime(time_in, "%I:%M %p")
            # Use today's date for old records (or adjust as needed)
            new_time = datetime.now().strftime("%Y-%m-%d") + " " + dt.strftime("%H:%M:%S")
            c.execute("UPDATE attendance SET time_in=? WHERE id=?", (new_time, rec_id))
        except ValueError:
            print(f"Skipping invalid record {rec_id}: {time_in}")

conn.commit()
conn.close()
print("✅ All old records converted to 24-hour ISO format")

# ------------------------------
# DATABASE FUNCTIONS
# ------------------------------

def db():
    if not os.path.exists("db"):
        os.makedirs("db")
    return sqlite3.connect(DB_PATH)
    
def db_attendance():
    if not os.path.exists("db"):
        os.makedirs("db")
    return sqlite3.connect(DB_ATTENDANCE_PATH)

def init_db():
    conn = db()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    """)

    conn.commit()

    # Create default admin
    c.execute("SELECT * FROM users WHERE email='admin@school.com'")
    if not c.fetchone():
        c.execute("INSERT INTO users(email, password, role) VALUES (?,?,?)",
                  ("admin@school.com", "admin123", "admin"))
        conn.commit()

    conn.close()

init_db()


# ------------------------------
# ROUTES
# ------------------------------
@app.route("/")
def home():
    session.clear()
    return render_template("index.html", logged_in=False)

# --------------------------------
# ATTENDANCE
# --------------------------------
@app.route("/attendance")
def attendance():
    date_filter = request.args.get('date')
    conn = db_attendance()  # <-- correct DB
    c = conn.cursor()

    if date_filter:
        c.execute("""
            SELECT idno, lastname, firstname, course, level, time_in
            FROM attendance
            WHERE DATE(time_in)=?
            ORDER BY time_in ASC
        """, (date_filter,))
    else:
        c.execute("""
            SELECT idno, lastname, firstname, course, level, time_in
            FROM attendance
            ORDER BY time_in ASC
        """)

    records = [dict(
        idno=row[0],
        lastname=row[1],
        firstname=row[2],
        course=row[3],
        level=row[4],
        time_in=row[5]
    ) for row in c.fetchall()]

    conn.close()
    return render_template("attendance.html", attendance_records=records)

@app.route("/scan_qr/<idno>")
def scan_qr(idno):
    student = getrecord("students", idno=idno)
    
    if student:
        student = student[0]
        conn = db_attendance()
        c = conn.cursor()

        # 🔹 Current local time in 24-hour ISO format
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        c.execute("""
            INSERT INTO attendance (idno, lastname, firstname, course, level, time_in)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (student['idno'], student['lastname'], student['firstname'],
              student['course'], student['level'], current_time))

        conn.commit()
        conn.close()
        flash(f"✅ Attendance recorded for {student['lastname']}, {student['firstname']}!", "success")
    else:
        flash("⚠️ Student not found!", "error")
    
    return redirect(url_for("attendance"))



@app.route("/check", methods=["GET"])
def check():
    idno = request.args.get("idno")
    student = getrecord("students", idno=idno)

    if student:
        student = student[0]

        conn = db_attendance()
        c = conn.cursor()

        # 🔹 Current local time in 24-hour ISO format
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        c.execute("""
            INSERT INTO attendance (idno, lastname, firstname, course, level, time_in)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (student['idno'], student['lastname'], student['firstname'],
              student['course'], student['level'], current_time))

        conn.commit()
        conn.close()

        return render_template("scan_result.html", 
                               student=student, 
                               message="Attendance recorded!")
    
    return render_template("scan_result.html", 
                           student=None, 
                           message="Student not found!")
                           
@app.template_filter('datetimeformat')
def datetimeformat(value):
    """
    Convert a 24-hour format string from DB to 12-hour format with AM/PM.
    Example: '2025-12-08 14:45:12' -> '2025-12-08 02:45:12 PM'
    """
    dt = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    return dt.strftime("%Y-%m-%d %I:%M:%S %p")


# --------------------------------
# LOGIN
# --------------------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Auto logout if user is logged in
    session.clear()
    
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password'].strip()

        conn = db()
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
        user = c.fetchone()
        conn.close()

        if user:
            session['user'] = email
            session['logged_in'] = True

            role = str(user[3]).strip().lower() if user[3] else "user"
            session['role'] = role
            
            flash("✅ Logged in successfully!", "success")

            if role == "admin":
                return redirect(url_for('admin'))
            else:
                return redirect(url_for('studentmanagement'))

        else:
            return render_template('login.html', error="Invalid credentials")

    return render_template('login.html')

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"].strip()
        password = request.form["password"].strip()

        conn = db()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users(email, password, role) VALUES (?, ?, 'admin')", (email, password))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            return render_template("login.html", register_error="⚠️ Email already exists!", register_email=email)

        conn.close()
        flash("✅ Registered successfully!", "success")
        return redirect("/login")

    return render_template("register.html")



# --------------------------------
# ADMIN PAGE
# --------------------------------
@app.route("/admin")
def admin():
    if not session.get("logged_in"):
        return redirect("/login")

    # Optional query param to prefill the left panel
    selected_user = None
    user_id = request.args.get("id")
    conn = db()
    c = conn.cursor()

    if user_id:
        c.execute("SELECT id, email, password FROM users WHERE id=?", (user_id,))
        row = c.fetchone()
        if row:
            selected_user = dict(id=row[0], email=row[1], password=row[2])

    # Fetch all users, sorted by email
    c.execute("SELECT id, email, password FROM users ORDER BY email ASC")
    users = [dict(id=row[0], email=row[1], password=row[2]) for row in c.fetchall()]
    conn.close()

    return render_template("admin.html", users=users, selected_user=selected_user)


# ADD OR EDIT USER
@app.route("/admin/add", methods=["POST"])
def admin_add():
    user_id = request.form.get("id")  # hidden input when editing
    email = request.form["email"].strip()
    password = request.form["password"].strip()

    conn = db()
    c = conn.cursor()
    try:
        if user_id:  # Edit existing user
            c.execute("UPDATE users SET email=?, password=? WHERE id=?", (email, password, user_id))
            conn.commit()
            flash("✅ User updated successfully!", "success")
            return redirect(url_for("admin"))
        else:  # Add new user
            c.execute("INSERT INTO users(email, password, role) VALUES (?, ?, 'admin')", (email, password))
            conn.commit()
            flash("✅ User added successfully!", "success")
            return redirect(url_for("admin"))
            
    except sqlite3.IntegrityError:
        # Email already exists → render login page with modal open and error
        conn.close()
        return render_template("login.html", register_error="⚠️ Email already exists!", register_email=email)
    finally:
        conn.close()
    
    return redirect(url_for("admin"))


# DELETE USER
@app.route("/admin/delete/<int:user_id>")
def admin_delete(user_id):
    conn = db()
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()
    flash("✅ User deleted successfully!", "success")
    return redirect(url_for("admin"))


# --------------------------------
# STUDENT MANAGEMENT
# --------------------------------
@app.route("/studentmanagement")
def studentmanagement():
    students = getall("students")
    return render_template(
        "studentmanagement.html",
        logged_in=True,
        user=session.get("user"),
        username=session.get("user", "Guest"),
        userid=session.get("user", "Guest"),
        studentlist=students,
        selected_student=None
    )
    
@app.route("/student/add")
def student_add_page():
    return render_template("student.html", student=None)
    

    student['image_data'] = image_data
    return render_template("student.html", student=student)

@app.route("/add", methods=['POST'])
def add_student():
    idno = request.form['idno'].strip()
    lastname = request.form['lastname'].strip()
    firstname = request.form['firstname'].strip()
    course = request.form['course'].strip()
    level = request.form['level'].strip()

    # 🔹 Check for missing fields
    if not idno or not lastname or not firstname or not course or not level:
        flash("⚠️ All fields are required. Please fill in all fields before saving.", "error")
        return redirect(url_for('studentmanagement'))

    # 🔹 Ensure ID number is numeric
    if not idno.isdigit():
        flash("⚠️ ID Number must be numeric.", "error")
        return redirect(url_for('studentmanagement'))

    # 🔹 Check for existing ID number
    existing_student = getrecord('students', idno=idno)
    if existing_student:
        flash(f"⚠️ ID Number {idno} already exists!", "error")
        return redirect(url_for('studentmanagement'))

    # 🔹 Handle image upload
    image_file = request.files.get('image')
    image_filename = None
    if image_file and allowed_file(image_file.filename):
        image_filename = f"{idno}_{secure_filename(image_file.filename)}"
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
        image_file.save(image_path)

    # 🔹 Save record if everything is valid
    addrecord('students', idno=idno, lastname=lastname, firstname=firstname,
               course=course, level=level, image=image_filename)
    flash("✅ Student record added successfully!", "success")
    return redirect(url_for('studentmanagement'))


@app.route("/delete/<idno>")
def delete_student(idno):
    deleterecord('students', idno=idno)
    flash("✅ Student record deleted successfully!", "success")
    return redirect(url_for('studentmanagement'))


@app.route("/edit/<idno>", methods=['GET', 'POST'])
def edit_student(idno):
    if request.method == 'POST':
        lastname = request.form['lastname'].strip()
        firstname = request.form['firstname'].strip()
        course = request.form['course'].strip()
        level = request.form['level'].strip()

        # 🔹 Block saving with missing fields
        if not lastname or not firstname or not course or not level:
            flash("⚠️ All fields must be filled before saving changes.", "error")
            return redirect(url_for('edit_student', idno=idno))

        image_file = request.files.get('image')
        record = getrecord('students', idno=idno)[0]

        if image_file and allowed_file(image_file.filename):
            if record['image']:
                old_path = os.path.join(app.config['UPLOAD_FOLDER'], record['image'])
                if os.path.exists(old_path):
                    os.remove(old_path)
            image_filename = f"{idno}_{secure_filename(image_file.filename)}"
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
            image_file.save(image_path)
        else:
            image_filename = record['image']

        updaterecord('students', idno=idno, lastname=lastname, firstname=firstname,
                     course=course, level=level, image=image_filename)
        flash("✅ Student record updated successfully!", "success")
        return redirect(url_for('studentmanagement'))
    else:
        student = getrecord('students', idno=idno)[0]
        students = getall('students')
        return render_template('studentmanagement.html',
                               student=student,
                               selected_student=student,
                               studentlist=students,
                               logged_in=True,
                               user=session.get("user"),
                               username=session.get("user", "Guest"),
                               userid=session.get("user", "Guest")
                               )

# Route used by the sidebar 'User Mgmt' button
@app.route("/user_mgmt")
def user_mgmt():
    # redirect to admin (user management) page
    return redirect(url_for("admin"))

# Route to open a specific student into the left edit panel
@app.route("/student_mgmt")
def student_mgmt():
    idno = request.args.get("id")
    if not idno:
        return redirect(url_for("studentmanagement"))

    student = getrecord("students", idno=idno)[0]
    students = getall("students")

    return render_template(
        "studentmanagement.html",
        logged_in=True,
        user=session.get("user"),
        username=session.get("user", "Guest"),
        userid=session.get("user", "Guest"),
        selected_student=student,
        studentlist=students
    )
    
# --------------------------------
# STUDENT.HTML
# --------------------------------
@app.route("/student")
def student():
    return render_template("student.html")
    

@app.route("/student/edit/<idno>")
def student_edit_page(idno):
    record = getrecord("students", idno=idno)
    if not record:
        flash("⚠️ Student not found!", "error")
        return redirect(url_for("studentmanagement"))

    student = dict(record[0])  # <-- convert Row to mutable dict

    # Load image as base64 if exists
    image_data = None
    if student['image']:
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], student['image'])
        if os.path.exists(image_path):
            with open(image_path, "rb") as f:
                encoded = base64.b64encode(f.read()).decode()
                image_data = f"data:image/jpeg;base64,{encoded}"

    student['image_data'] = image_data
    return render_template("student.html", student=student)



@app.route("/student/save", methods=["POST"])
def save_student():
    idno = request.form.get("idno").strip()
    lastname = request.form.get("lastname").strip()
    firstname = request.form.get("firstname").strip()
    course = request.form.get("course").strip()
    level = request.form.get("level").strip()
    picture = request.form.get("picture") # base64 from camera snap
    
    existing = getrecord("students", idno=idno)
    is_edit = bool(existing)
    
    image_filename = None
    if picture and "," in picture:
        header, encoded = picture.split(",", 1)
        image_filename = f"{idno}.jpg"
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
        with open(image_path, "wb") as f:
            f.write(base64.b64decode(encoded))

    elif is_edit:
        image_filename = existing[0]['image'] if existing else None

    if is_edit:
        updaterecord("students", idno=idno, lastname=lastname, firstname=firstname,
                     course=course, level=level, image=image_filename)
        flash("✅ Student updated successfully!", "success")
    else:
        addrecord("students", idno=idno, lastname=lastname, firstname=firstname,
                  course=course, level=level, image=image_filename)
        flash("✅ Student added successfully!", "success")

    return redirect(url_for("studentmanagement"))
    
    
# --------------------------------
# LOGOUT
# --------------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# ------------------------------
# RUN
# ------------------------------
if __name__ == "__main__":
    app.run(debug=True)
